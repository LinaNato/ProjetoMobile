package com.example.unifykhatib.projetomobile;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
    public void esqueciSenha(View v){
        TextView tv= (TextView) findViewById(R.id.textView);
        tv.setTextColor(Color.BLUE);
        Intent intent = new Intent(LoginActivity.this, EsqueciSenhaActivity.class);
        startActivity(intent);
    }
    public void registrar(View v){
        Intent i = new Intent(LoginActivity.this, RegistrarActivity.class);
        startActivity(i);
    }
    public void logar(View v){
        Intent i = new Intent(LoginActivity.this, MenuActivity.class);
        startActivity(i);
    }
}
