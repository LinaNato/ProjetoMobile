package com.example.unifykhatib.projetomobile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegistrarActivity extends AppCompatActivity {


    EditText nome, senha, codigo;
    RadioButton masculino, feminino, outros;
    RadioGroup sexo;
    Spinner idade;

    private DatabaseReference referencia = FirebaseDatabase.getInstance().getReference();
    DatabaseReference usuario_cadastro = referencia.child("usuarios");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(RegistrarActivity.this,
                R.array.idades, android.R.layout.simple_selectable_list_item);
        Spinner idade = (Spinner) findViewById(R.id.spinner);
        idade.setAdapter(adapter);
        sexo = findViewById(R.id.radioGroup);
    }

    public void voltar(View v){
        Intent i = new Intent(RegistrarActivity.this, LoginActivity.class);
        startActivity(i);
    }

    public void Confirmar(View v) {
            Usuario user = new Usuario();
            nome = (EditText)findViewById(R.id.editText5);
            senha = (EditText)findViewById(R.id.editText7) ;
            codigo = (EditText)findViewById(R.id.editText9) ;
            idade = (Spinner)findViewById(R.id.spinner);
            user.setNome(nome.getText().toString());
            user.setSenha(senha.getText().toString());
            user.setCodigo(codigo.getText().toString());
            user.setIdade(idade.getSelectedItem().toString());
            user.setSexo("m");



            usuario_cadastro.push().setValue(user);


        Intent i = new Intent(RegistrarActivity.this, MenuActivity.class);
        startActivity(i);
    }

}

